package com.easeljs.html5.client.easeljs;

import com.google.gwt.user.client.ui.VerticalPanel;

public interface IEasel {

	public void load(VerticalPanel panel);
	
}
